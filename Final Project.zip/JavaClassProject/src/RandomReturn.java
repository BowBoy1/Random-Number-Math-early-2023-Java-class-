import java.util.Random;
public class RandomReturn extends NumReturn {

	
	private int min;
	private int max;
	
	public RandomReturn(int minVal, int maxVal) {
		min = minVal;
		max = maxVal;
	}
	
	//returns a random number between the values being input

	@Override
	public int returnNumber() {
		Random rand = new Random();
		return rand.nextInt(min, max);
	}

}
