import javafx.scene.control.*;

public class UserInput {
	
	
	//fields
	private TextField minField;
	private TextField maxField;

	public UserInput(TextField MinInput, TextField MaxInput) {
		minField = MinInput;
		maxField = MaxInput;
	}
	
	//checks if min value is valid
	public int getMinValue() {
		String minString = minField.getText();
		try {
			int min = Integer.parseInt(minString);
			return min;
		}
		catch(NumberFormatException e) {
			return 1;
		}
	}
	
	//checks if max value is valid
	private int getBaseMax() {
		String maxString = maxField.getText();
		try {
			int max = Integer.parseInt(maxString);
			return max;
		}
		catch(NumberFormatException e) {
			return 3;
		}
	}
	
	
	//checks if maximum is greater than minimum
	public int getMaxValue() {
		int min = getMinValue();
		int max = getBaseMax();
		if (max > min) {
			return max;
		}
		else {
			max = min + 2;
			return max;
		}
	}

}
