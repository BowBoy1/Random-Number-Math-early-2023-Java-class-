
public abstract class NumReturn {

	public NumReturn() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract int returnNumber();

}
