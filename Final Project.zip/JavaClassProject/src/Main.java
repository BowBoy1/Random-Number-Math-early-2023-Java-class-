
 
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.text.*;
import javafx.geometry.*;
import javafx.scene.paint.*;

 
public class Main extends Application {
	
	//buttons.
	Button rButton1; 
    Button rButton2;
    Button rButton3;
    Button rerollButton;
    Button doubleOutput;
    Button halfOutput;
    Button squareOutput;
    
    //text fields.
    TextField minField;
    TextField maxField;
    
    //output
    Label output;
    NumCalc calculator;
	
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
    	//creating labels
    	Label randomInstructions = new Label("Select a random number  \nto add to the output.\nIf invalid inputs were given by the user\n then defaults will be used:"); 
    	Label minInstructions = new Label("Minimum random number:"); 
    	Label maxInstructions = new Label("Maximum random number:");
    	Label outLabel = new Label("Output:");
    	output = new Label("0");
    	Label operations = new Label("Output Math Operations:");

        //text field for minimum random number
        minField = new TextField();

        //text field for maximum random number
        maxField = new TextField();

        //Creating Random Number Buttons 
        rButton1 = new Button("0"); 
        rButton2 = new Button("0");
        rButton3 = new Button("0");
        //Creating Reroll button
        rerollButton = new Button("Reroll Numbers");
        //Creating Math Operation Buttons
        doubleOutput = new Button("Double the output");
        halfOutput = new Button("Half the output");
        squareOutput = new Button("Square the output");
        

        //Creating a Grid Pane 
        GridPane gridPane = new GridPane();

        //Setting size for the pane
        gridPane.setMinSize(500, 400); 

        //Setting the padding
        gridPane.setPadding(new Insets(10, 40, 10, 10)); 

        //Setting the vertical and horizontal gaps between the columns 
        gridPane.setVgap(5); 
        gridPane.setHgap(50);

        //Setting the Grid alignment 
        gridPane.setAlignment(Pos.TOP_CENTER); 

        //random nodes 
        gridPane.add(randomInstructions, 0, 0); 
        gridPane.add(rButton1, 0, 2); 
        gridPane.add(rButton2, 0, 4);
        gridPane.add(rButton3, 0, 6); 
        gridPane.add(rerollButton, 0, 10);
        //min and max nodes
        gridPane.add(minInstructions, 0, 21);
        gridPane.add(minField, 0, 22); 
        gridPane.add(maxInstructions, 0, 23);
        gridPane.add(maxField, 0, 24);
        //output label nodes
        gridPane.add(outLabel, 3, 0);
        gridPane.add(output, 3, 2);
        //math operation nodes
        gridPane.add(operations, 3, 21);
        gridPane.add(doubleOutput, 3, 22);
        gridPane.add(halfOutput, 3, 23);
        gridPane.add(squareOutput, 3, 24);
        
        //output label border things
        output.setBorder(new Border(new BorderStroke(Color.color(0.7,0.7,0.7), BorderStrokeStyle.SOLID, new CornerRadii(0), BorderStroke.THIN)));
        

        //Creating a scene object 
        Scene scene = new Scene(gridPane);

        //Setting title to the Stage 
        stage.setTitle("Random Number Math"); 

        //Adding scene to the stage 
        stage.setScene(scene); 

        //Displaying the contents of the stage 
        stage.show();
        
        interactions();
        
    }

    
    
    private void interactions() {
    	
    	calculator = new NumCalc();
    	
    	
        //making buttons do things
        rerollButton.setOnAction(new EventHandler<ActionEvent>() {
        	 
            @Override
            public void handle(ActionEvent event) {
                reroll();
            }
        });
        //-------------------------------------------------------------------------------------------
        
        rButton1.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	int num = Integer.parseInt(rButton1.getText());
            	setOutput(calculator.numAdd(num));
                reroll();
            }
        });
        //-------------------------------------------------------------------------------------------
        
        rButton2.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	int num = Integer.parseInt(rButton2.getText());
            	setOutput(calculator.numAdd(num));
                reroll();
            }
        });
        //-------------------------------------------------------------------------------------------
        
        rButton3.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	int num = Integer.parseInt(rButton3.getText());
            	setOutput(calculator.numAdd(num));
                reroll();
            }
        });
        //-------------------------------------------------------------------------------------------
        
        doubleOutput.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	setOutput(calculator.outDouble());
            }
        });
        //-------------------------------------------------------------------------------------------
        
        halfOutput.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	setOutput(calculator.outHalf());
            }
        });
        //-------------------------------------------------------------------------------------------
        
        squareOutput.setOnAction(new EventHandler<ActionEvent>() {
       	 
            @Override
            public void handle(ActionEvent event) {
            	setOutput(calculator.outSquare());
            }
        });
        
    	
    }
    
    
    private void reroll() {
    	UserInput input = new UserInput(minField, maxField);
    	RandomReturn randomOne = new RandomReturn(input.getMinValue(), input.getMaxValue());
    	rButton1.setText(Integer.toString(randomOne.returnNumber()));
    	rButton2.setText(Integer.toString(randomOne.returnNumber()));
    	rButton3.setText(Integer.toString(randomOne.returnNumber()));
    }
    
    
    private void setOutput(int theOutput) {
    	output.setText(Integer.toString(theOutput));
    }
}
