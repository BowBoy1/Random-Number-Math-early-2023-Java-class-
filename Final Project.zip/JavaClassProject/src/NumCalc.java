
public class NumCalc {
	
	private int output = 0;

	public NumCalc() {
		
	}
	
	//add a number to the output
	public int numAdd(int num) {
		output += num;
		return output;
	}
	
	//double output
	public int outDouble() {
		output = output * 2;
		return output;
	}
	
	//half output
	public int outHalf() {
		output = output / 2;
		return output;
	}
	
	//square output
	public int outSquare() {
		output = output * output;
		return output;
	}
	

}
